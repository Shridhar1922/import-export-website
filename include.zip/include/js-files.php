<a href="//api.whatsapp.com/send?phone=918850923640&text=WHATEVER_LINK_OR_TEXT_YOU_WANT_TO_SEND" class=" whatsapp"
    aria-label="Whatsapp" target="_blank">
    <i class="icofont-brand-whatsapp"></i>
</a>
<a href="#" id="scroll">
    <i class="icofont-simple-up"></i>
</a>

<script src="assets/js/jquery-migrate-3.3.2.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/vendor-js/filter.min.js"></script>
<script src="assets/js/vendor-js/odometer.min.js"></script>
<script src="assets/js/vendor-js/owl.carousel.min.js"></script>
<script src="assets/js/vendor-js/lity.min.js"></script>
<script src="assets/js/aos.min.js"></script>
<script src="assets/js/main.js"></script>
<script>
AOS.init();
</script>
</body>

</html>